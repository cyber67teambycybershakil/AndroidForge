"""Shakil Server starter API. Python 3.10+, no third-party dependencies.
Development only: HTTP, no TLS, single process. Put behind HTTPS before public use.
"""
import base64
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

DB = os.getenv('SHAKIL_DB', 'shakil.db')
HOST = os.getenv('SHAKIL_HOST', '127.0.0.1')
PORT = int(os.getenv('SHAKIL_PORT', '8765'))
ADMIN_KEY = os.getenv('SHAKIL_ADMIN_KEY', '')

def connect():
    c = sqlite3.connect(DB, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    return c

def init():
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL,
          salt TEXT NOT NULL, password_hash TEXT NOT NULL,
          created_at INTEGER NOT NULL, suspended_until INTEGER DEFAULT NULL,
          banned INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS sessions (
          token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
          expires_at INTEGER NOT NULL, last_seen INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS reports (
          id INTEGER PRIMARY KEY, reporter_id INTEGER NOT NULL REFERENCES users(id),
          reported_id INTEGER NOT NULL REFERENCES users(id),
          reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
          created_at INTEGER NOT NULL);
        CREATE INDEX IF NOT EXISTS reports_target_idx ON reports(reported_id);
        CREATE TABLE IF NOT EXISTS moderation_actions (
          id INTEGER PRIMARY KEY, target_id INTEGER NOT NULL REFERENCES users(id),
          action TEXT NOT NULL, reason TEXT NOT NULL, created_at INTEGER NOT NULL);
        ''')

def password_hash(password, salt):
    return hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), 250000).hex()

def user_for_token(c, token):
    if not token: return None
    digest = hashlib.sha256(token.encode()).hexdigest()
    return c.execute('''SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id
      WHERE s.token_hash=? AND s.expires_at>?''', (digest, int(time.time()))).fetchone()

def blocked(user):
    return bool(user['banned'] or (user['suspended_until'] and user['suspended_until'] > int(time.time())))

class Handler(BaseHTTPRequestHandler):
    def send(self, status, obj):
        raw = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(raw)

    def body(self):
        length = int(self.headers.get('Content-Length', '0'))
        if length > 16384: raise ValueError('Request too large')
        return json.loads(self.rfile.read(length) or b'{}')

    def admin(self):
        supplied = self.headers.get('X-Admin-Key', '')
        return bool(ADMIN_KEY and hmac.compare_digest(supplied, ADMIN_KEY))

    def auth(self, c):
        value = self.headers.get('Authorization', '')
        token = value[7:] if value.startswith('Bearer ') else ''
        user = user_for_token(c, token)
        if not user:
            self.send(401, {'error':'Authentication required'}); return None
        if blocked(user):
            self.send(403, {'error':'Account suspended or banned'}); return None
        c.execute('UPDATE sessions SET last_seen=? WHERE token_hash=?',
                  (int(time.time()), hashlib.sha256(token.encode()).hexdigest()))
        c.commit()
        return user

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/health':
            return self.send(200, {'ok': True, 'service': 'Shakil Server'})
        if not self.admin(): return self.send(403, {'error':'Admin access required'})
        with connect() as c:
            now = int(time.time())
            if path == '/admin/stats':
                total = c.execute('SELECT COUNT(*) FROM users').fetchone()[0]
                online = c.execute('''SELECT COUNT(DISTINCT user_id) FROM sessions
                  WHERE expires_at>? AND last_seen>?''', (now, now-120)).fetchone()[0]
                reports = c.execute('SELECT COUNT(*) FROM reports').fetchone()[0]
                suspended = c.execute('SELECT COUNT(*) FROM users WHERE banned=1 OR suspended_until>?',(now,)).fetchone()[0]
                return self.send(200, {'total_users':total,'online_users':online,'total_reports':reports,'suspended_users':suspended})
            if path == '/admin/users':
                rows = c.execute('''SELECT u.id,u.username,u.created_at,u.suspended_until,u.banned,
                  COUNT(r.id) report_count,COUNT(DISTINCT r.reporter_id) unique_reporters
                  FROM users u LEFT JOIN reports r ON r.reported_id=u.id
                  GROUP BY u.id ORDER BY report_count DESC, u.id''').fetchall()
                return self.send(200, {'users':[dict(r) for r in rows]})
            if path == '/admin/reports':
                rows = c.execute('''SELECT r.*, a.username reporter, b.username reported
                  FROM reports r JOIN users a ON a.id=r.reporter_id
                  JOIN users b ON b.id=r.reported_id ORDER BY r.id DESC LIMIT 200''').fetchall()
                return self.send(200, {'reports':[dict(r) for r in rows]})
        self.send(404, {'error':'Not found'})

    def do_POST(self):
        path = urlparse(self.path).path
        try: data = self.body()
        except (ValueError, json.JSONDecodeError): return self.send(400, {'error':'Invalid JSON or size'})
        now = int(time.time())
        with connect() as c:
            if path == '/auth/register':
                username, password = str(data.get('username','')).strip(), str(data.get('password',''))
                if not (3 <= len(username) <= 32 and username.replace('_','').isalnum() and len(password) >= 12):
                    return self.send(400, {'error':'Username 3-32 letters/numbers/underscore; password at least 12 characters'})
                salt = secrets.token_hex(16)
                try:
                    cur = c.execute('INSERT INTO users(username,salt,password_hash,created_at) VALUES(?,?,?,?)',
                              (username,salt,password_hash(password,salt),now))
                    c.commit()
                except sqlite3.IntegrityError: return self.send(409, {'error':'Username taken'})
                return self.send(201, {'id':cur.lastrowid,'username':username})
            if path == '/auth/login':
                u = c.execute('SELECT * FROM users WHERE username=?',(str(data.get('username','')),)).fetchone()
                password = str(data.get('password',''))
                if not u or not hmac.compare_digest(password_hash(password,u['salt']),u['password_hash']):
                    return self.send(401, {'error':'Invalid credentials'})
                if blocked(u): return self.send(403, {'error':'Account suspended or banned'})
                token = secrets.token_urlsafe(32)
                c.execute('INSERT INTO sessions VALUES(?,?,?,?)',
                          (hashlib.sha256(token.encode()).hexdigest(),u['id'],now+86400,now))
                c.commit()
                return self.send(200, {'token':token,'expires_in':86400,'user_id':u['id']})
            if path == '/reports':
                user = self.auth(c)
                if not user: return
                target = data.get('reported_user_id')
                reason = str(data.get('reason','')).strip()
                if not isinstance(target,int) or target == user['id'] or not 5 <= len(reason) <= 1000:
                    return self.send(400, {'error':'Invalid report'})
                if not c.execute('SELECT 1 FROM users WHERE id=?',(target,)).fetchone():
                    return self.send(404, {'error':'User not found'})
                # Rate-limit identical reports from one reporter about one target within 24h.
                if c.execute('SELECT 1 FROM reports WHERE reporter_id=? AND reported_id=? AND created_at>?',
                             (user['id'],target,now-86400)).fetchone():
                    return self.send(429, {'error':'Already reported this user in the last 24 hours'})
                cur = c.execute('INSERT INTO reports(reporter_id,reported_id,reason,created_at) VALUES(?,?,?,?)',
                                (user['id'],target,reason,now))
                c.commit()
                return self.send(201, {'report_id':cur.lastrowid})
            if path in ('/admin/suspend','/admin/restore','/admin/ban'):
                if not self.admin(): return self.send(403, {'error':'Admin access required'})
                uid, reason = data.get('user_id'), str(data.get('reason','')).strip()
                if not isinstance(uid,int) or not reason: return self.send(400, {'error':'user_id and reason required'})
                if not c.execute('SELECT 1 FROM users WHERE id=?',(uid,)).fetchone():
                    return self.send(404, {'error':'User not found'})
                if path == '/admin/suspend':
                    hours = data.get('hours')
                    if not isinstance(hours,int) or not 1 <= hours <= 8760: return self.send(400, {'error':'hours must be 1-8760'})
                    c.execute('UPDATE users SET suspended_until=?,banned=0 WHERE id=?',(now+hours*3600,uid))
                elif path == '/admin/ban':
                    c.execute('UPDATE users SET banned=1 WHERE id=?',(uid,))
                else:
                    c.execute('UPDATE users SET suspended_until=NULL,banned=0 WHERE id=?',(uid,))
                c.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
                c.execute('INSERT INTO moderation_actions(target_id,action,reason,created_at) VALUES(?,?,?,?)',
                          (uid,path.rsplit('/',1)[-1],reason,now))
                c.commit()
                return self.send(200, {'ok':True,'user_id':uid})
        self.send(404, {'error':'Not found'})

if __name__ == '__main__':
    init()
    if not ADMIN_KEY:
        raise SystemExit('Set SHAKIL_ADMIN_KEY to a strong random secret before starting')
    print(f'Shakil Server listening at http://{HOST}:{PORT} (development only)')
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
