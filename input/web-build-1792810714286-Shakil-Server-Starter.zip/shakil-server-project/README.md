# Shakil Server — starter source ZIP

This is a **working Python starter backend**, not a complete Android Server APK. It implements SQLite-backed registration, login, bearer-token authentication, reporting, report counts, online-session approximation, and administrator suspension/ban/restore endpoints. It does **not** implement Android UI, messaging, WebSockets, image uploads, public hosting, or large-scale production infrastructure.

## Run on a computer or compatible Python environment

Python 3.10+ required; no external Python dependencies.

```bash
cd backend
export SHAKIL_ADMIN_KEY="replace-with-a-long-random-secret"
python src/server.py
```

Windows PowerShell: `$env:SHAKIL_ADMIN_KEY="..."` then `python src/server.py`.

The API listens on `127.0.0.1:8765` by default. Do not expose this HTTP development server directly to the public internet. The SQLite file is created in the working directory. This code has not been packaged as an Android app and cannot be installed as an APK.

See `docs/API.md` for endpoints and `docs/ARCHITECTURE.md` for limitations and future Android app work.
