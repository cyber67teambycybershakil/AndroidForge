# Android Server APK status

NOT IMPLEMENTED. This directory is reserved for the future native Android app. Do not treat this ZIP as an installable APK.
