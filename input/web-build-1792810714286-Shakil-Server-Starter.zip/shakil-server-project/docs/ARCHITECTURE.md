# Architecture and missing work

This ZIP is a runnable backend foundation with standard-library Python and SQLite. It is not an Android app, nor is it production-ready. The requested Android foreground service, logo, dashboard UI, connected-app registration, full REST authentication middleware, WebSockets, real-time online presence, 24-hour private message expiry, media, notifications, TLS, admin role management, backups, and tests remain to be built.

To create **Shakil Server APK**, implement a native Android project (Kotlin/Java), use a supported embedded server framework, adapt the backend logic to Android, add a foreground service and dashboard, and build/test on Android. This ZIP intentionally does not contain fake Android/Gradle files.

For deployment, use HTTPS behind a trusted reverse proxy, protect administrator keys, implement rate limiting, proper session rotation, privacy safeguards, and a database suited to the target scale. Carrier CGNAT and Android background restrictions can prevent worldwide access. A phone cannot reliably support 500,000 concurrent users.
