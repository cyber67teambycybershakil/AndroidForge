# API — v0.1 starter

JSON requests, JSON responses. Default base URL `http://127.0.0.1:8765` (development only).

| Method | Endpoint | Access | Body / result |
|---|---|---|---|
| GET | `/health` | Public | Health status |
| POST | `/auth/register` | Public | `{ "username": "shakil", "password": "at-least-12-chars" }` |
| POST | `/auth/login` | Public | Same body; returns bearer token |
| POST | `/reports` | Bearer token | `{ "reported_user_id": 2, "reason": "Spam messages" }` |
| GET | `/admin/stats` | `X-Admin-Key` | User, online, report, suspended counts |
| GET | `/admin/users` | `X-Admin-Key` | User list with `report_count` and `unique_reporters` |
| GET | `/admin/reports` | `X-Admin-Key` | Last 200 reports |
| POST | `/admin/suspend` | `X-Admin-Key` | `{ "user_id": 2, "hours": 24, "reason": "Reviewed reports" }` |
| POST | `/admin/ban` | `X-Admin-Key` | `{ "user_id": 2, "reason": "Reviewed serious violation" }` |
| POST | `/admin/restore` | `X-Admin-Key` | `{ "user_id": 2, "reason": "Appeal approved" }` |

**How connected apps use authentication and suspension:** Register/login via API, store token securely, and send `Authorization: Bearer <token>` for authenticated requests. Suspended/banned users cannot log in or submit reports; their sessions are revoked. Any *other* app must explicitly integrate these APIs and enforce suspension in its own routes and real-time connections. This starter does not provide a complete shared authentication middleware for arbitrary apps.

**Online users:** Count of unique users with unexpired login sessions active in the last 120 seconds. Currently only authenticated report requests refresh activity. This is **not** real-time WebSocket presence tracking.

**Reports:** 24-hour same-reporter/target cooldown. Admin must review reports; never auto-ban on report counts alone.
